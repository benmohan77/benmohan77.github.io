var queue; // LoadQueue
var stage; // Stage
var blocks; // Our landscape in a 2D array
var dirt;

// Landscape Generation Vars
var stageXdimens;
var stageYdimens;
var stageXblocks;
var stageYblocks;
var landMin;
var landMax;
var landBlockSize;
var maxLandDev;

// Player Tank Vars
var p1Tank;
var p1TankBitmap;
var p1TankBarrel;
var p2Tank;
var p2TankBitmap;
var p2TankBarrel;

//Player Control Vars
var p1Rright;
var p1Rleft;
var p2Rleft;
var p2Rright;
var p1RrightPressed;
var p1RleftPressed;
var p2RleftPressed;
var p2RrightPressed;
var fire;

//Key variables
const ARROW_KEY_LEFT = 37;
const ARROW_KEY_UP = 38;
const ARROW_KEY_RIGHT = 39;
const ARROW_KEY_DOWN = 40;
var upKeyDown = false;
var downKeyDown = false;
var leftKeyDown = false;
var rightKeyDown = false;

var g;

//Player Turn
var p1turn;
var RED_TURN = "Red";
var GREEN_TURN = "Green"


//Data displays
var p1elev;
var p2elev;
var nowPlayingLabel;

//Tank x Index On GRID
var p1XGrid = 5;
var p2XGrid = 30;

function load() {
    queue = new createjs.LoadQueue(false);
    queue.on("complete", init, this);
    queue.loadManifest([
        { id: "p1TankPNG", src: "red_tank.png" },
        { id: "p1TankBarrel", src: "red_tank_barrel.png" },
        { id: "p2TankPNG", src: "green_tank.png" },
        { id: "p2TankBarrel", src: "green_tank_barrel.png" },
    ]);
}

function init() {
    stage = new createjs.Stage("canvas");
    g = new createjs.Graphics();

    initButtons();
    landGeneration();
    addTanks();



    p1elev = new createjs.Text(p1TankBarrel.rotation, "20px Arial", "#000000");
    p1elev.x = 100;
    p1elev.y = 30;
    stage.addChild(p1elev);

    nowPlayingLabel = new createjs.Text("Player: " + RED_TURN, "20px Arial", "#000000");
    nowPlayingLabel.x = 250;
    nowPlayingLabel.y = 25;
    stage.addChild(nowPlayingLabel);



    // KEYBOARD
    window.onkeydown = handleKeyDown;
    window.onkeyup = handleKeyUp;

    p1turn = false;

    stage.update();
    createjs.Ticker.setFPS(60);
    createjs.Ticker.addEventListener("tick", tick);
}

function p1rotateRight() {
    p1TankBarrel.rotation = p1TankBarrel.rotation + 1;

}


function tick(event) {
    if (p1turn) {
        rotateBarrel(p1TankBarrel);
        moveTank(p1Tank);
    } else {
        rotateBarrel(p2TankBarrel);
        moveTank(p2Tank);
    }
    playerLabel();


    if (!event.paused) {
        stage.update();
    }

}

function addTanks() {
    // Get our images
    p1TankPNG = new createjs.Bitmap(queue.getResult("p1TankPNG"));
    p1TankBarrel = new createjs.Bitmap(queue.getResult("p1TankBarrel"));
    p2TankPNG = new createjs.Bitmap(queue.getResult("p2TankPNG"));
    p2TankBarrel = new createjs.Bitmap(queue.getResult("p2TankBarrel"));

    p1TankBarrel.regX = 0;
    p1TankBarrel.regY = 2.5;

    p2TankBarrel.regX = 0;
    p2TankBarrel.regY = 2.5;

    p1TankBarrel.x = 10;
    p1TankBarrel.y = 10;

    p2TankBarrel.y = 10;
    p2TankBarrel.x = 10;



    p1Tank = new createjs.Container();
    p1Tank.addChild(p1TankBarrel);

    p1Tank.addChild(p1TankPNG);

    p2Tank = new createjs.Container();
    p2Tank.addChild(p2TankBarrel);

    p2Tank.addChild(p2TankPNG);

    // Find the starting positions for the tanks
    var p1pos = (blocks[p1XGrid].length); // 0;
    // alert("Hello!");
    // for (var y = 0; y < stageYblocks; y++)
    // {
    //     alert("Hi!");
    //     alert(blocks[4][y]);
    //     // console.log(blocks[4][y]);
    //     if (blocks[4][y] == null) {
    //         p1pos = y;
    //     }
    //     else {
    //         break;
    //     }
    // }
    var p2pos = (blocks[p2XGrid].length); // 0;
    // for (var y = 0; y < stageYblocks; y++)
    // {
    //     if (blocks[stageXblocks - 5][y] == null) {
    //         p2pos = y;
    //     }
    //     else {
    //         break;
    //     }
    // }

    p1Tank.x = landBlockSize * 5
    p1Tank.y = stageYdimens - (landBlockSize * p1pos);



    p2Tank.x = (30) * landBlockSize;
    p2Tank.y = stageYdimens - (landBlockSize * p2pos);

    stage.addChild(p1Tank);
    stage.addChild(p2Tank);
    //alert("Hi!");
}
function playerLabel() {
    if (p1turn) {
        nowPlayingLabel.text = "Player: " + RED_TURN;
    } else {
        nowPlayingLabel.text = "Player: " + GREEN_TURN;
    }
}

//initializes the buttons for controlling the tanks
function initButtons() {

    //Player 1 Button Initialization
    p1Rright = new createjs.Shape();
    p1Rright.graphics.beginStroke("#000000").beginFill("#000000").drawPolyStar(15, 15, 15, 3, .5, 0);

    p1Rleft = new createjs.Shape();
    p1Rleft.graphics.beginStroke("#000000").beginFill("#000000").drawPolyStar(15, 15, 15, 3, .5, 180);

    fire = new createjs.Shape();
    fire.graphics.beginStroke("#000000").beginFill("#ff0000").drawCircle(5, 5, 10);
    fire.x = 150;
    fire.y = 35;

    fire.addEventListener("click", function () {
        if (p1turn) {
            p1turn = false;
        } else {
            p1turn = true;
        }
    });
    stage.addChild(fire);


    p1Rleft.on("mousedown", function() {
        p1RleftPressed = true;
    });
    p1Rleft.on("pressup", function() {
        p1RleftPressed = false;
    });

    p1Rright.on("mousedown", function() {
        p1RrightPressed = true;
    })

    p1Rright.on("pressup", function() {
        p1RrightPressed = false;
    });

    p1Rright.x = 60;
    p1Rright.y = p1Rleft.y = 25;
    p1Rleft.x = 40;



    stage.addChild(p1Rright, p1Rleft, p1elev);
}

function landGeneration() {
    stageXdimens = stage.canvas.width;
    stageYdimens = stage.canvas.height;
    landBlockSize = 20;
    maxLandDev = 1; // The max amount the land can deviate per step either way when generating
    landMin = (stageYdimens / landBlockSize) * 0.20; // Land must be at least 20% above bottom
    landMax = (stageYdimens / landBlockSize) * 0.60; // Land must not exceed 60% above bottom
    stage.update(); // why is this here?

    // Create the graphics block used to make landscape blocks
    g.beginStroke("#8B4513").beginFill("#D2691E");
    g.drawRect(0, 0, landBlockSize, landBlockSize);

    // Get the starting position for the landscape
    var m = getRandomInt(landMin, landMax);

    blocks = get2DArray(stageXdimens / landBlockSize);

    // Add random blocks as terrain
    for (i = 0; i < stageXdimens / landBlockSize; i++) {
        m = getRandomInt(m - maxLandDev, m + maxLandDev + 1);
        if (m < landMin) {
            m = landMin;
        }
        if (m > landMax) {
            m = landMax;
        }
        for (j = 0; j < m; j++) {
            blocks[i][j] = new createjs.Shape(g);
        }
    }

    // Place blocks on the correct screen positions
    for (i = 0; i < blocks.length; i++) {
        for (j = 0; j < blocks[i].length; j++) {
            blocks[i][j].x = landBlockSize * i;
            blocks[i][j].y = y_bot(landBlockSize * j);
            stage.addChild(blocks[i][j]);
        }
    }

    stageXblocks = blocks.length;
    stageYblocks = blocks[0].length;
}

function y_bot(y) {
    return (stageYdimens - y);
}

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

function get2DArray(size) {
    size = size > 0 ? size : 0;
    var arr = [];

    while (size--) {
        arr.push([]);
    }

    return arr;
}


function handleKeyDown(e) {
    switch (e.keyCode) {
        case ARROW_KEY_UP: upKeyDown = true; break;
        case ARROW_KEY_DOWN: downKeyDown = true; break;
        case ARROW_KEY_LEFT: leftKeyDown = true; break;
        case ARROW_KEY_RIGHT: rightKeyDown = true; break;
    }
}

function handleKeyUp(e) {
    switch (e.keyCode) {
        case ARROW_KEY_UP: upKeyDown = false; break;
        case ARROW_KEY_DOWN: downKeyDown = false; break;
        case ARROW_KEY_LEFT: leftKeyDown = false; break;
        case ARROW_KEY_RIGHT: rightKeyDown = false; break;
    }
}

function rotateBarrel(shape) {
        if ((p1RleftPressed || upKeyDown) && (shape.rotation > -180)) {
            shape.rotation = shape.rotation - 1;
            p1elev.text = -(shape.rotation);
        }
        if ((p1RrightPressed || downKeyDown) && (shape.rotation < 0)) {
            shape.rotation = shape.rotation + 1;
            p1elev.text = -(shape.rotation);
        }
}

function moveRedTank(){
		if (leftKeyDown && (p1Tank.x > 0)) {
			p1XGrid--;
			var pos = (blocks[p1XGrid].length);
   	 		p1Tank.x = landBlockSize * p1XGrid;
    		p1Tank.y = stageYdimens - (landBlockSize * pos);
		}

		if (rightKeyDown && (tank.x < stageXdimens)) {
				p1XGrid++;
				var pos = (blocks[gridPOS].length);
		   	 	p1Tank.x = landBlockSize * gridPOS;
		    	p1Tank.y = stageYdimens - (landBlockSize * pos);
		}


}
